"""
Nexus Example Package

A sample Python package for demonstrating Nexus repository publishing.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from . import hello

__all__ = ["hello"]
